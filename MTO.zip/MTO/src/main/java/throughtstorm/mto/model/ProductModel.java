package throughtstorm.mto.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import throughtstorm.mto.constant.ProductStatus;

@Data
public class ProductModel {

    @JsonProperty("enterprise productId")
    private Long productId;

    @JsonProperty("enterprise productName")
    private String productName;

    @JsonProperty("enterprise productDescription")
    private String productDescription;

    @JsonProperty("enterprise category")
    private String category;

    @JsonProperty("enterprise status")
    ProductStatus status;

    // Constructors, getters, and setters
}
