package throughtstorm.mto.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import throughtstorm.mto.entity.Product;
import throughtstorm.mto.model.ProductModel;
import throughtstorm.mto.repository.ProductRepository;




@Service
public class ProductService {
	
	@Autowired
	ProductRepository productRepository ;

   
	public List<ProductModel> getAllProducts() {
        List<Product> products = productRepository.findAll();
        return products.stream()
                .map(this::convertToModel)
                .collect(Collectors.toList());
    }

    private ProductModel convertToModel(Product product) {
        ProductModel productModel = new ProductModel();
        productModel.setProductId(product.getId());
        productModel.setProductName(product.getName());
        productModel.setProductDescription(product.getDescription());
        productModel.setStatus(product.getStatus());
        return productModel;
    }

}
