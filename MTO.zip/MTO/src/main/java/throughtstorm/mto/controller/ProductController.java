package throughtstorm.mto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import throughtstorm.mto.constant.ProductStatus;
import throughtstorm.mto.entity.Product;
import throughtstorm.mto.model.ProductModel;
import throughtstorm.mto.repository.ProductRepository;
import throughtstorm.mto.service.ProductService;

@RestController
@RequestMapping("/api/products")
public class ProductController {

	
	  @Autowired
	    private ProductService productService;
	  
	  @Autowired
	  ProductRepository productRepository;
	  
	  

	  
	  @GetMapping("/ping")
	  public String ping() {
			
			  Product prod = new Product();
			  
			  prod.setChangeRequestRef("ChangeRequestRef.Test"); prod.setCatalogId(111);
			  prod.setDescription("prod.desc"); prod.setStatus(ProductStatus.CREATED);
			  
			  productRepository.save(prod);
			 
		  
		  return "UP and Running .....";
	  }
	  
	  @GetMapping("/allProducts")
	    public ResponseEntity<List<ProductModel>> getAllProducts() {
	        List<ProductModel> products = productService.getAllProducts();
	        if (products.isEmpty()) {
	            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	        return new ResponseEntity<>(products, HttpStatus.OK);
	    }
}
