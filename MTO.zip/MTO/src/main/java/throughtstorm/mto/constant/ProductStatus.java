package throughtstorm.mto.constant;

public enum ProductStatus {
    DRAFT,
    CREATED
}