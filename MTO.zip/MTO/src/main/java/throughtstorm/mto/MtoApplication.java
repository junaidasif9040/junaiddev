package throughtstorm.mto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MtoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MtoApplication.class, args);
	}

}
