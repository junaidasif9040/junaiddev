package throughtstorm.mto.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "Enterprise_Product")
@Data
public class Product {
	
	

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "PRODUCT_ID")
	    private Long id;

	    @Column(name = "PRODUCT_NAME", length = 50)
	    private String name;

	    @Column(name = "PRODUCT_DESCRIPTION", length = 256)
	    private String description;

	    @Column(name = "CHANGE_REQUEST_REF", length = 50)
	    private String changeRequestRef;

	    @Column(name = "PRODUCT_TYPE_ID")
	    private Integer productTypeId;

	    @Column(name = "PRODUCT_CATEGORY_ID")
	    private Integer productCategoryId;

	    @Column(name = "CATALOG_ID")
	    private Integer catalogId;

	    @Column(name = "PRODUCT_STATUS")
	    private Integer productStatus;

	    @Column(name = "FINANCIAL_PRODUCT_FLAG")
	    private Boolean financialProductFlag;

	    @Column(name = "START_DATE")
	    private LocalDateTime startDate;

	    @Column(name = "END_DATE")
	    private LocalDateTime endDate;

	    @Column(name = "CREATED_DATE")
	    private LocalDateTime createdDate;

	    @Column(name = "MODIFIED_DATE")
	    private LocalDateTime modifiedDate;

	   
	    @Enumerated(EnumType.STRING)
	    @Column(name = "STATUS", length = 20)
	    private throughtstorm.mto.constant.ProductStatus status;
	   
	    @Column(name = "CREATED_BY", length = 50)
	    private String createdBy;

	    @Column(name = "MODIFIFED_BY", length = 50)
	    private String modifiedBy;

	    
	}
	


