package throughtstorm.mto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MtoApplicationTests {

	@Test
	void contextLoads() {
	}

}
